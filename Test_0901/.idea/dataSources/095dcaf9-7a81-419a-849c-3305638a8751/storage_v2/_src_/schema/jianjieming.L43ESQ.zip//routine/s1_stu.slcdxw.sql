create procedure s1_stu()
  begin
  select
    s.Sname,
    group_concat(c.Cname),
    group_concat(ss.score)
  from Student s left join SC ss on s.SID = ss.SID
    left join Course c on c.CID = SS.CID
  group by s.SID;
end;

