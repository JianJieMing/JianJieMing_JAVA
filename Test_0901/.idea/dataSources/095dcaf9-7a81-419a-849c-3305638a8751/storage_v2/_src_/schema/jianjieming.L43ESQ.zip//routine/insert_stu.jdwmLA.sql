create procedure insert_stu(IN SID int, IN name varchar(200), IN birthday date, IN gender varchar(20), OUT qty int)
  begin
    select qty;
    insert into Student (SID,Sname,Sage,Ssex) 
    value
    (SID,name,birthday,gender);
    set qty = (select row_count());
    end;

