create procedure query_stu()
  select * from Student;

